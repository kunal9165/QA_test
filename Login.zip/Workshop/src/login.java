import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
public class login 
{

    public static void main(String[] args) throws InterruptedException 
        {
        System.setProperty("webdriver.chrome.driver","C:\\Users\\KUNAL GUPTA\\Downloads\\chromedriver_win32\\chromedriver.exe");
         
        WebDriver driver = new ChromeDriver();
     //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        driver.get("https://www.amazon.in/ap/signin?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.in%2F%3Fref_%3Dnav_ya_signin&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=inflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&");
        System.out.println(driver.getTitle());
        //System.out.println(driver.getCurrentUrl());
        
     //Email_or_username_section
        
        //Direct_click
        driver.findElement(By.xpath("//*[@id=\"continue\"]")).click();
        Thread.sleep(5000);
        
     //wrong_email
        driver.findElement(By.xpath("//*[@id=\"ap_email\"]")).sendKeys("kunal12@leewayhertz.com");
        //Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id=\"continue\"]")).click();
        Thread.sleep(5000);
       
        driver.findElement(By.xpath("//*[@id=\"ap_email\"]")).clear();
        
     //valid_email
        driver.findElement(By.xpath("//*[@id=\"ap_email\"]")).sendKeys("kunal@leewayhertz.com");
        Thread.sleep(5000);
        
        driver.findElement(By.xpath("//*[@id=\"continue\"]")).click();
        
     //Password_section
        
     //Direct_click
        driver.findElement(By.xpath("//*[@id=\"signInSubmit\"]")).click();
        Thread.sleep(5000);
        
     //Wrong_password
        driver.findElement(By.xpath("//*[@id=\"ap_password\"]")).sendKeys("kunal@9165");
        Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id=\"signInSubmit\"]")).click();
        Thread.sleep(5000);
        
        driver.findElement(By.xpath("//*[@id=\"ap_password\"]")).clear();
      
     //Valid_password
        driver.findElement(By.xpath("//*[@id=\"ap_password\"]")).sendKeys("kunal9165");
        
        driver.findElement(By.xpath("//*[@id=\"authportal-main-section\"]/div[2]/div[1]/div/div/form/div/div[2]/div/div/label/div/label/input")).click();
        //Thread.sleep(5000);
        
        driver.findElement(By.xpath("//*[@id=\"signInSubmit\"]")).click();
        
        String a=driver.getCurrentUrl();
        System.out.println(driver.getCurrentUrl());
        
     String v= "https://www.amazon.in/?ref_=nav_ya_signin&";
        
     if(a.equalsIgnoreCase(v))
     {
       
        	
         System.out.println("Pass!");
        }
     
         else
        	 
        {
         System.out.println("Fail!");
       }

    
        }

}